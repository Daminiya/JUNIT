package com.sgic.automation.demo.pages;

public class UserManagementPage {

}
