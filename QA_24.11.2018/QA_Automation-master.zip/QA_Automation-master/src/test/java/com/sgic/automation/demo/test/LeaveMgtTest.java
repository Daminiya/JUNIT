package com.sgic.automation.demo.test;

public class LeaveMgtTest extends BaseTest{

}
