package com.sgic.automation.demo.util;

public class DataStore {

}
